import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.commons.Method;
import org.objectweb.asm.tree.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.*;

/**
 * Created by dxble on 10/18/17.
 */
public class ExtractMethod {
    public static void main(final String args[]) throws Exception {
        FileInputStream is = new FileInputStream(args[0]);

        ClassReader classReader = new ClassReader(is);
        ClassNode classNode = new ClassNode();
        classReader.accept(classNode,0);

        //Search for the wanted method
        final List<MethodNode> methods = classNode.methods;
        InsnList l = new InsnList();
        //Map<LabelNode, LabelNode> labels = new HashMap<>();
        for(MethodNode methodNode: methods){
            if(methodNode.name.equals("testPrintLines")){

                // The first line of this method starts from index 3 of instructions list
                AbstractInsnNode node = methodNode.instructions.get(3);
                for (; node != null; node = node.getNext()) {
                    l.add(node);// Actually need to clone, but do not yet know how. The api doc is sort of unintuitive
                }

            }
        }
        MethodNode mnode = new MethodNode(Opcodes.ACC_PUBLIC + Opcodes.ACC_STATIC, "goo", "()V", null, null);
        mnode.instructions.add(l);
        methods.add(mnode);

        for(MethodNode methodNode: methods){
            if(methodNode.name.equals("testPrintLines")){

                AbstractInsnNode node = methodNode.instructions.get(3);
                MethodInsnNode gooMNode = new MethodInsnNode(Opcodes.INVOKESTATIC, "Test", "goo", "()V", false);
                methodNode.instructions.insertBefore(node, gooMNode);
                methodNode.instructions.insertBefore(node, new InsnNode(Opcodes.RETURN)); // This is a hack of deleting all subsequent instructions
                //methodNode.instructions.set(node, new InsnNode(Opcodes.RETURN)); // If set, we probably need clone earlier
            }
        }


        //Generate the Class
        ClassWriter classWriter = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
        classNode.accept(classWriter);

        FileOutputStream fos = new FileOutputStream(args[1]);
        fos.write(classWriter.toByteArray());
        fos.close();
    }

}


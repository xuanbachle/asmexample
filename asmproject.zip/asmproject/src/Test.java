/**
 * Created by dxble on 10/18/17.
 */
public class Test
{
    public static void main(String[] args) {
        testPrintLines();
    }

    public static void testPrintLines() {
        printLine1();
        printLine2();
        printLine3();
    }

    public static void printLine1() {
        System.out.println("Line 1");
    }

    public static void printLine2() {
        System.out.println("Line 2");
    }

    public static void printLine3() {
        System.out.println("Line 3");
    }
}
